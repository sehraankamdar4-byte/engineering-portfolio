Open index.html in any modern browser. All project images and the resume download are embedded in the HTML, so no internet connection or other files are required.
